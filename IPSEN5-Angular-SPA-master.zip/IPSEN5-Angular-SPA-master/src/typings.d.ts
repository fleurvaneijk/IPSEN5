declare var StripeCheckout: any;
