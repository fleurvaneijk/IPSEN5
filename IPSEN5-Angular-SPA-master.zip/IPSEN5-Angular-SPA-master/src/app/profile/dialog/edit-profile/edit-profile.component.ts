import {Component, Inject, OnInit} from '@angular/core';
import {MatDialogRef} from '@angular/material';
import {AccountService} from '../../service/account.service';
import {MAT_DIALOG_DATA} from '@angular/material';
import {User} from '../../../core/shared/models/user.model';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  user: User;
  emailCorrect = true;
  nameCorrect = true;
  username = '';
  email = '';

  constructor(public editAcc: MatDialogRef<EditProfileComponent>,
              private accountService: AccountService,
              @Inject(MAT_DIALOG_DATA) public data: any) {
    this.user = data.user;
  }

  ngOnInit() {
  }

  cancel() {
    this.editAcc.close();
  }

  save(name, email) {
    console.log(name, email);

    // if (this.checkEmail(email)) {
    //   // const newUser: User = this.user;
    //   // newUser.email = email;
    //   // newUser.fullName = username;
    //   //
    //   // this.accountService.update(newUser);
    //   // this.editAcc.close();
    // }
  }

  checkEmail(email: string): boolean {
    if (email.includes('@') && email.includes('.')) {
      return true;
    } else {
      return false;
    }
  }

  checkName(): boolean {
    return true;
  }
}
