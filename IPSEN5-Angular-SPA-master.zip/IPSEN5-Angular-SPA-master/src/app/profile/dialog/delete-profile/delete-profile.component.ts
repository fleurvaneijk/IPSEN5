import { Component, OnInit } from '@angular/core';
import {MatDialogRef} from '@angular/material';
import {AccountService} from '../../service/account.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete-profile.component.html',
  styleUrls: ['./delete-profile.component.css']
})
export class DeleteProfileComponent implements OnInit {

  constructor(private deleteAcc: MatDialogRef<DeleteProfileComponent>, private accountService: AccountService) { }

  ngOnInit() {
  }

  cancel() {
    this.deleteAcc.close();
  }

  deleteConfirmed() {
    this.accountService.deleteUser();
  }
}
