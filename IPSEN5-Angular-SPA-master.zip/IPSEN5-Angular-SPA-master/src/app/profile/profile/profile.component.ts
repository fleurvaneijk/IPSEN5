import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';
import {EditProfileComponent} from '../dialog/edit-profile/edit-profile.component';
import {AccountService} from '../service/account.service';
import {DeleteProfileComponent} from '../dialog/delete-profile/delete-profile.component';
import {AuthService} from '../../core/shared/services/auth.service';
import {User} from '../../core/shared/models/user.model';
import {Song} from '../../catalog/model/song';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

export class ProfileComponent implements OnInit {
  user: User;
  songs: Song[] = [];

  constructor(public dialog: MatDialog, public accountService: AccountService, private authService: AuthService) {

  }

  ngOnInit() {
    this.getUser();
  }

  editAccount(): void {
    const dialogRef = this.dialog.open(EditProfileComponent, {
      width: '500px',
      data: {user: this.user}
    });
  }

  deletePressed(): void {
    const dialogRef = this.dialog.open(DeleteProfileComponent, {
      width: '400px'
    });
  }

  private loadOrderHistory() {
    for (const order of this.user.orderHistory) {
      this.accountService.fetchSongFromID(order);
    }
  }

  private getUser() {
    this.authService.getCurUser().subscribe((user: User) => {
      this.user = user;
      console.log(user);

      this.accountService.orders = [];
      this.loadOrderHistory();
    });
  }
}
