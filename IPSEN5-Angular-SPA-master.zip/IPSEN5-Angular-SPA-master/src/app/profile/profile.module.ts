import {NgModule} from '@angular/core';
import {ProfileRoutingModule} from './profile-routing.module';
import {EditProfileComponent} from './dialog/edit-profile/edit-profile.component';
import {ProfileComponent} from './profile/profile.component';
import {MatModule} from '../core/mat.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ReactiveFormsModule} from '@angular/forms';
import {AccountService} from './service/account.service';
import {OrderHistoryComponent} from './order-history/order-history.component';
import {AngularFirestore} from '@angular/fire/firestore';
import {AngularFireStorage} from '@angular/fire/storage';
import {OrderHistoryService} from './service/order-history.service';
import {DeleteProfileComponent} from './dialog/delete-profile/delete-profile.component';

@NgModule({
  declarations: [
    EditProfileComponent,
    ProfileComponent,
    OrderHistoryComponent,
    DeleteProfileComponent
  ],
  imports: [
    ProfileRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MatModule
  ],
  exports: [
    EditProfileComponent,
    ProfileComponent,
    ProfileRoutingModule,
    DeleteProfileComponent
  ],
  entryComponents: [
    EditProfileComponent,
    DeleteProfileComponent
  ],
  providers: [
    AccountService,
    AngularFirestore,
    AngularFireStorage,
    OrderHistoryService
  ]
})

export class ProfileModule {
}
