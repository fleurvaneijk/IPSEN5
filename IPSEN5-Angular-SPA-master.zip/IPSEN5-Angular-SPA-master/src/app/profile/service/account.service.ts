import {Injectable} from '@angular/core';
import {AngularFirestore, AngularFirestoreDocument} from '@angular/fire/firestore';
import {AngularFireStorage} from '@angular/fire/storage';

import {OrderModel} from '../model/order.model';
import {User} from '../../core/shared/models/user.model';
import {AuthService} from '../../core/shared/services/auth.service';
import {OrderHistoryRecord} from '../../core/shared/models/order-history.model';
import {Song} from '../../catalog/model/song';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  songRef: any;
  itemDoc: AngularFirestoreDocument;
  orders: OrderModel[] = [];
  user: User;

  constructor(private afs: AngularFirestore, private storage: AngularFireStorage, private authService: AuthService) {
  }

  getUser(): User {
    return this.user;
  }

  update(user: User) {
    this.itemDoc = this.afs.collection('users').doc(user.docId);
    this.itemDoc.update({
      name: user.fullName,
      email: user.email
    });

    // firebase.auth().currentUser.updateEmail(user.email).then().catch();

  }

  deleteUser() {
    // this.itemDoc = this.afs.collection('users').doc(id);
    // this.itemDoc.collection('orderhistory');
    // this.itemDoc.delete-profile();
  }

  fetchSongFromID(order: OrderHistoryRecord) {
    this.songRef = this.afs.firestore.collection('songs').doc(order.songId).get().then( (song) => {
        this.renderOrderSong(song, order.date);
    }).catch();
  }

  private renderOrderSong(song, date: number) {
    this.storage.ref(song.data().image).getDownloadURL().subscribe(imgUrl => {
      this.storage.ref(song.data().audio).getDownloadURL().subscribe( audioUrl => {
        this.storage.ref(song.data().license).getDownloadURL().subscribe( licenseUrl => {
          this.orders.push(new class implements OrderModel {
            orderDate: Date = new Date(date);
            song: Song = new Song(song.data().id, song.data().title, song.data().artist, audioUrl, null, imgUrl, licenseUrl,
            song.data().genre, song.data().duration, song.data().price, song.data().tags, song.data().speed, song.data().key,
            song.data().extraInfo);
          });
        });
      });
    });
  }
}
