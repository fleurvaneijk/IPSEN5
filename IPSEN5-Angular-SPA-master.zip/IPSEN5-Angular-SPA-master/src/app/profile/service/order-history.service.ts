import {Injectable} from '@angular/core';
import {AngularFirestore} from '@angular/fire/firestore';
import {AuthService} from '../../core/shared/services/auth.service';
import {Subscription} from 'rxjs';
import {OrderHistoryRecord} from '../../core/shared/models/order-history.model';
import {User} from '../../core/shared/models/user.model';

@Injectable()
export class OrderHistoryService {

  constructor(private afs: AngularFirestore, private auth: AuthService) {
  }

  authUserObservable: Subscription;

  public saveOrder(songId: string) {

    let userDocId;
    let orderHistory: Array<OrderHistoryRecord>;

    this.authUserObservable = this.auth.getCurUser().subscribe((data: User) => {
      userDocId = data.docId;

      orderHistory = data.orderHistory || new Array<OrderHistoryRecord>();
      orderHistory.push({songId: songId, date: Date.now()});

      this.afs.collection('users').doc(userDocId).update({
        orderHistory: orderHistory
      }).then(() => {
        this.unsubscribeAuthUser();
      });
    });
  }

  private unsubscribeAuthUser() {
    this.authUserObservable.unsubscribe();
  }
}
