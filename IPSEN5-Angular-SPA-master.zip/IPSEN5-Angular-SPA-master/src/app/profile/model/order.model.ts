import {Song} from '../../catalog/model/song';

export interface OrderModel {
  orderDate?: Date;
  song?: Song;
}
