import {OrderModel} from './order.model';

export interface Profile {
  name?: string;
  email?: string;
  id?: string;
  // password?: string;
  orderHistory?: OrderModel[];
}
