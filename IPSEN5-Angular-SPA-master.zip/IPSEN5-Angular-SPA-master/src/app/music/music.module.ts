import {NgModule} from '@angular/core';
import {MatModule} from '../core/mat.module';
import {BrowserModule} from '@angular/platform-browser';
import {MusicListComponent} from './music-list/music-list.component';
import {MatGridListModule, MatProgressSpinnerModule} from '@angular/material';
import {MusicRoutingModule} from './music-routing.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {FileDropModule} from 'ngx-file-drop';
import {ModifySongComponent} from './dialog/modify-song/modify-song.component';
import {AddSongComponent} from './dialog/add-song/add-song.component';

@NgModule({
  declarations: [
    MusicListComponent,
    AddSongComponent,
    ModifySongComponent,
  ],
  imports: [
    MatModule,
    BrowserModule,
    MatGridListModule,
    FormsModule,
    ReactiveFormsModule,
    FileDropModule,
    MatProgressSpinnerModule
  ],
  entryComponents: [
    AddSongComponent,
    ModifySongComponent
  ],
  exports: [
    MusicListComponent,
    MusicRoutingModule,
    ModifySongComponent
  ]
})
export class MusicModule {
}
