import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {MusicListComponent} from './music-list/music-list.component';
import {AdminGuard} from '../auth/guard/admin.guard';

const adminMusicRoutes: Routes = [
  {path: 'music', component: MusicListComponent, canActivate: [AdminGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(adminMusicRoutes)],
  exports: [RouterModule]
})
export class MusicRoutingModule { }
