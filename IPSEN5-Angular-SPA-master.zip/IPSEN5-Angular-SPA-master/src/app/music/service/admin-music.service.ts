import {Injectable, OnInit} from '@angular/core';
import {AngularFireStorage} from '@angular/fire/storage';
import * as firebase from 'firebase';
import {NgForm} from '@angular/forms';
import {AngularFirestore} from '@angular/fire/firestore';
import {Song} from '../../catalog/model/song';
import {__await} from 'tslib';
import {BehaviorSubject, Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminMusicService implements OnInit {
  private previewPath = '/preview';
  private coversPath = '/covers';
  private songsPath = '/songs';
  private pdfPath = '/pdf';
  songs = [];
  songsSubject: BehaviorSubject<Song[]> = new BehaviorSubject([]);
  preview: FormDataEntryValue;

  constructor(private afStorage: AngularFireStorage, private afs: AngularFirestore, private storage: AngularFireStorage) {
    this.setUpSongs();
  }

  ngOnInit() {
  }

  setUpSongs() {
    const songs = [];
    this.afs.firestore.collection('songs').get().then((snapshot) => {
      snapshot.docs.forEach(doc => {
        songs.push(this.renderSong(doc));
      });
      this.songsSubject.next(songs);
    });
  }

  renderSong(doc) {
    return new Song(doc.id, doc.data().title, doc.data().artist, doc.data().audio, doc.data().preview, doc.data().image,
      doc.data().license, doc.data().genre,
      doc.data().duration, doc.data().price, doc.data().tags, doc.data().speed, doc.data().key, doc.data().extraInfo);
  }

  deleteSong(deleteLst) {
    for (const entry of deleteLst) {
      const previewRef = this.afStorage.ref('').child(`${entry.preview}`);
      const audioRef = this.afStorage.ref('').child(`${entry.audio}`);
      const licenseRef = this.afStorage.ref('').child(`${entry.license}`);
      const coverRef = this.afStorage.ref('').child(`${entry.image}`);
      this.deletePreview(previewRef);
      this.deleteAudio(audioRef);
      this.deleteLicense(licenseRef);
      this.deleteCover(coverRef);
      this.afs.collection('songs').doc(entry.id).delete();
    }
  }

  deletePreview(previewRef) {
    previewRef.delete();
  }

  deleteAudio(audioRef) {
    audioRef.delete();
  }

  deleteLicense(licenseRef) {
    licenseRef.delete();
  }

  deleteCover(coverRef) {
    coverRef.delete();
  }

  uploadData(form: NgForm, fd: FormData) {
    const preview = fd.get('previewFile');
    const song = fd.get('songFile');
    const pdf = fd.get('pdfFile');
    const cover = fd.get('coverFile');
    this.uploadPreview(preview);
    this.uploadSong(song);
    this.uploadPdf(pdf);
    this.uploadCover(cover);
    this.pathSetter(form, preview, song, pdf, cover);
  }

  uploadPreview(upload) {
    this.uploader(`${this.previewPath}/${upload.name}`, upload);
  }

  uploadSong(upload) {
    this.uploader(`${this.songsPath}/${upload.name}`, upload);
  }

  uploadCover(upload) {
    this.uploader(`${this.coversPath}/${upload.name}`, upload);
  }

  uploadPdf(upload) {
    this.uploader(`${this.pdfPath}/${upload.name}`, upload);
  }

  uploader(path, upload) {
    this.afStorage.upload(path, upload);
  }

  pathSetter(form: NgForm, preview, song, pdf, cover) {
    form.value.preview = `preview/${preview.name}`;
    form.value.audio = `songs/${song.name}`;
    form.value.license = `pdf/${pdf.name}`;
    form.value.image = `covers/${cover.name}`;
    const data = Object.assign({}, form.value);
    this.push(data);
  }

  push(data) {
    firebase.firestore().collection('songs').add(data).catch(res => console.log(res));
  }

  updateSong(song, fd: FormData, newSong) {
    const preview = fd.get('previewFile');
    const sonq = fd.get('songFile');
    const pdf = fd.get('pdfFile');
    const cover = fd.get('coverFile');
    if (preview !== song.preview) {
      const previewRef = this.afStorage.ref('').child(`${song.preview}`);
      this.deletePreview(previewRef);
      this.uploadPreview(preview);
      this.updatePreview(preview, song.id);
    }
    if (sonq !== song.audio) {
      const songRef = this.afStorage.ref('').child(`${song.audio}`);
      this.deleteSong(songRef);
      this.uploadSong(sonq);
      this.updateAudio(sonq, song.id);
    }
    if (pdf !== song.license) {
      const licenseRef = this.afStorage.ref('').child(`${song.license}`);
      this.deleteLicense(licenseRef);
      this.uploadPdf(pdf);
      this.updateLicense(pdf, song.id);
    }
    if (cover !== song.image) {
      const coverRef = this.afStorage.ref('').child(`${song.image}`);
      this.deleteCover(coverRef);
      this.uploadCover(cover);
      this.updateCover(cover, song.id);
    }
    this.afs.collection('songs').doc(song.id).update({
      title: newSong.title,
      artist: newSong.artist,
      genre: newSong.genre,
      duration: newSong.duration,
      price: newSong.price,
      tags: newSong.tags,
      speed: newSong.speed,
      key: newSong.key,
      extraInfo: newSong.extraInfo,
    }).then(res => console.log('user updated'));
  }

  updatePreview(preview, id) {
    this.afs.collection('songs').doc(id).update({
      preview: `preview/${preview.name}`,
    });
  }

  updateAudio(song, id) {
    this.afs.collection('songs').doc(id).update({
      audio: `songs/${song.name}`,
    });
  }

  updateLicense(pdf, id) {
    this.afs.collection('songs').doc(id).update({
      license: `pdf/${pdf.name}`,
    });
  }

  updateCover(cover, id) {
    this.afs.collection('songs').doc(id).update({
      image: `covers/${cover.name}`,
    });
  }

  getImageDownload(image): Observable<any> {
    return this.storage.ref(image).getDownloadURL();
  }
}

