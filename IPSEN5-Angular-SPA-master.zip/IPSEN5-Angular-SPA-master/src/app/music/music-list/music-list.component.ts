import {Component, OnInit} from '@angular/core';
import {MatDialog, MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {AdminMusicService} from '../service/admin-music.service';
import {ConfirmationDialogComponent} from '../../core/shared/confirmation-dialog/confirmation-dialog.component';
import {AddSongComponent} from '../dialog/add-song/add-song.component';
import {ModifySongComponent} from '../dialog/modify-song/modify-song.component';
import {map} from 'rxjs/operators';
import {Song} from '../../catalog/model/song';

export class DataTitles {
  id: string;
  artist: string;
  audio: string;
  duration: string;
  extraInfo: string;
  genre: string;
  key: string;
  license: string;
  price: number;
  preview: string;
  speed: number;
  tags: string;
  title: string;
  image: string;
  position: number;

  constructor(song: Song, position: number) {
    this.artist = song.artist;
    this.audio = song.audio;
    this.duration = song.duration;
    this.extraInfo = song.extraInfo;
    this.genre = song.genre;
    this.image = song.image;
    this.key = song.key;
    this.license = song.license;
    this.preview = song.preview;
    this.price = song.price;
    this.speed = song.speed;
    this.tags = song.tags;
    this.title = song.title;

    this.id = song.id;
    this.position = position;
  }

}

@Component({
  selector: 'app-music-list',
  templateUrl: './music-list.component.html',
  styleUrls: ['./music-list.component.css']
})

export class MusicListComponent implements OnInit {
  songList: DataTitles[] = [];
  displayedColumns: string[] = ['select', 'title', 'artist', 'genre', 'tags', 'speed', 'key'];
  selection = new SelectionModel<DataTitles>(true, []);
  dataSource: MatTableDataSource<DataTitles>;
  isLoaded = false;
  selected = null;

  constructor(public dialog: MatDialog, private adminMusicService: AdminMusicService) {
  }

  ngOnInit() {
    this.adminMusicService.songsSubject.pipe(map(songs => {
      const dataTiles = [];
      songs.forEach((song: Song, pos: number) => {
        dataTiles.push(new DataTitles(song, pos));
      });
      return dataTiles;
    })).subscribe(songs => {
      this.songList = songs;
      this.dataSource = new MatTableDataSource<DataTitles>(this.songList);
    });
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  removeRow() {
    const deleteLst = [];
    this.selection.selected.forEach(item => {
      const index: number = this.songList.findIndex(d => d === item);
      this.dataSource.data.splice(index, 1);
      this.dataSource = new MatTableDataSource<DataTitles>(this.dataSource.data);
      deleteLst.push(item);
    });
    this.selection = new SelectionModel<DataTitles>(true, []);
    this.adminMusicService.deleteSong(deleteLst);
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: DataTitles): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    this.selected = row.position;
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  }

  filterSongs(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  openAdd() {
    const dialogRef = this.dialog.open(AddSongComponent, {
      width: '600px',
      height: '500px',
    });
  }

  openModify() {
    this.selected = this.selection.selected;
    const dialogRef = this.dialog.open(ModifySongComponent, {
      width: '600px',
      height: '500px',
      data: this.selected
    });
  }

  openConfirmDialog() {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '350px',
      data: 'You are about to delete a song. Are you sure?'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.removeRow();
      }
    });
  }
}
