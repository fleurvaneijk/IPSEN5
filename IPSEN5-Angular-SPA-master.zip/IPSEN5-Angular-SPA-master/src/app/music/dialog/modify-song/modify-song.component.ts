import {Component, ElementRef, Inject, OnInit, ViewChild} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {FileSystemDirectoryEntry, FileSystemFileEntry, UploadEvent, UploadFile} from 'ngx-file-drop';
import {AdminMusicService} from '../../service/admin-music.service';
import {Song} from '../../../catalog/model/song';
import {FormControl, FormGroup, NgForm} from '@angular/forms';


@Component({
  selector: 'app-modify-song',
  templateUrl: './modify-song.component.html',
  styleUrls: ['./modify-song.component.css']
})
export class ModifySongComponent implements OnInit {
  constructor(@Inject(MAT_DIALOG_DATA) public data: any, private dialogRef: MatDialogRef<ModifySongComponent>,
              private adminMusicService: AdminMusicService) { }
  private files: UploadFile[] = [];
  previewFile: File = null;
  pdfFile: File = null;
  songFile: File = null;
  coverFile: File = null;
  imgPath;
  imgURL: any;
  isLoaded = false;
  modSongForm = new FormGroup({
    title: new FormControl(this.data[0].title),
    artist: new FormControl(this.data[0].artist),
    genre: new FormControl(this.data[0].genre),
    tags: new FormControl(this.data[0].tags),
    price: new FormControl(this.data[0].price),
    speed: new FormControl(this.data[0].speed),
    duration: new FormControl(this.data[0].duration),
    key: new FormControl(this.data[0].key),
    extraInfo: new FormControl(this.data[0].extraInfo)
  });
  ngOnInit() {
    this.isLoaded = true;
    this.adminMusicService.getImageDownload(this.data[0].image).subscribe(imgURL => {
      this.imgURL = imgURL;
    });
  }

  modifySong(form: FormGroup) {
    const song = new Song(
      null,
      form.value.title,
      form.value.artist,
      null,
     null,
      null,
     null,
     form.value.genre,
     form.value.duration,
      parseInt(form.value.price, 10),
     form.value.tags,
     parseInt(form.value.speed, 10),
     form.value.key,
     form.value.extraInfo,
    );
    const fd = new FormData();
    this.checkFile(fd, 'previewFile', this.previewFile, this.data[0].preview);
    this.checkFile(fd, 'songFile', this.songFile, this.data[0].audio);
    this.checkFile(fd, 'pdfFile', this.pdfFile, this.data[0].license);
    this.checkFile(fd, 'coverFile', this.coverFile, this.data[0].image);
    this.adminMusicService.updateSong(this.data[0], fd, song);
    this.dialogRef.close();
  }
  checkFile(fd, name, newFile, oldFile) {
    if (newFile === null) {
      fd.append(name, oldFile);
    } else {
      fd.append(name, newFile);
    }
  }

  onPreviewSelected(event) {
    this.previewFile = <File>event.target.files[0];
  }

  onPdfSelected(event) {
    this.pdfFile = <File>event.target.files[0];
  }

  onSongSelected(event) {
    this.songFile = <File>event.target.files[0];
  }

  public dropped(event: UploadEvent) {
    this.files = event.files;
    for (const droppedFile of event.files) {
      if (droppedFile.fileEntry.isFile) {
        const fileEntry = droppedFile.fileEntry as FileSystemFileEntry;
        fileEntry.file((file: File) => {
          this.coverFile = file;
          if (this.coverFile === null) {
            return;
          }
          const reader = new FileReader();
          this.imgPath = this.coverFile;
          reader.readAsDataURL(this.coverFile);
          reader.onload = (_event) => {
            this.imgURL = reader.result;
          };
        });
      } else {
        const fileEntry = droppedFile.fileEntry as FileSystemDirectoryEntry;
      }
    }
  }

}
