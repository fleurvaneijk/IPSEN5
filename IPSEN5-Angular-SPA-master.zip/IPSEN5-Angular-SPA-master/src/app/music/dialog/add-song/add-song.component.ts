import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {FileSystemDirectoryEntry, FileSystemFileEntry, UploadEvent, UploadFile} from 'ngx-file-drop';
import {AbstractControl, NgForm, ValidatorFn} from '@angular/forms';
import {AdminMusicService} from '../../service/admin-music.service';

@Component({
  selector: 'app-add-song',
  templateUrl: './add-song.component.html',
  styleUrls: ['./add-song.component.css']
})
export class AddSongComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: any, private dialogRef: MatDialogRef<AddSongComponent>,
              private adminMusicService: AdminMusicService) { }
  private files: UploadFile[] = [];
  previewFile: File;
  pdfFile: File;
  songFile: File;
  coverFile: File;
  imgPath;
  imgURL: any;

  addSong(form: NgForm) {
    const fd = new FormData();
    fd.append('title', form.value.title);
    fd.append('artist', form.value.artist);
    fd.append('genre', form.value.genre);
    fd.append('tags', form.value.tag);
    fd.append('price', form.value.price);
    fd.append('speed', form.value.speed);
    fd.append('duration', form.value.duration);
    fd.append('key', form.value.key);
    fd.append('extraInfo', form.value.key);
    fd.append('previewFile', this.previewFile);
    fd.append('songFile', this.songFile);
    fd.append('pdfFile', this.pdfFile);
    fd.append('coverFile', this.coverFile);
    fd.append('preview', null);
    fd.append('license', null);
    fd.append('image', null);
    fd.append('audio', null);
    this.adminMusicService.uploadData(form, fd);
    this.dialogRef.close();

  }
  onPreviewSelected(event) {
    this.previewFile = <File>event.target.files[0];
  }
  onPdfSelected(event) {
    this.pdfFile = <File>event.target.files[0];
  }
  onSongSelected(event) {
    this.songFile = <File>event.target.files[0];
  }
  public dropped(event: UploadEvent) {
    this.files = event.files;
    for (const droppedFile of event.files) {
      if (droppedFile.fileEntry.isFile) {
        const fileEntry = droppedFile.fileEntry as FileSystemFileEntry;
        fileEntry.file((file: File) => {
          this.coverFile = file;
          if (this.coverFile === null) {
            return;
          }
          const reader = new FileReader();
          this.imgPath = this.coverFile;
          reader.readAsDataURL(this.coverFile);
          reader.onload = (_event) => {
            this.imgURL = reader.result;
          };
        });
      } else {
        const fileEntry = droppedFile.fileEntry as FileSystemDirectoryEntry;
      }
    }
  }
  checkForm(form: NgForm) {
    if (form.valid && this.coverFile ) {
      return true;
    } else {
      return false;
    }
  }
}

