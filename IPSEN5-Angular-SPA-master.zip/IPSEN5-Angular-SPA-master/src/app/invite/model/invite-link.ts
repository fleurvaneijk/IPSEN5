import {DocumentData} from '@angular/fire/firestore';

export class InviteLink {
  docRef: string;
  used: boolean;
  role: string;
  userUID: string;
  codePart1: string;
  codePart2: string;
  codePart3: string;

  constructor(docRef: string, inviteLinkData: DocumentData) {
    this.docRef = docRef;
    this.used = inviteLinkData.used;
    this.role = inviteLinkData.role;
    this.userUID = inviteLinkData.userUID;
    this.codePart1 = inviteLinkData.codePart1;
    this.codePart2 = inviteLinkData.codePart2;
    this.codePart3 = inviteLinkData.codePart3;
  }

  getFullLink() {
    return window.location.origin + '/register/' + this.codePart1 + '/' + this.codePart2 + '/' + this.codePart3;
  }
}
