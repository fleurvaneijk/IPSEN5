import {Component} from '@angular/core';
import {MatDialogRef} from '@angular/material';

@Component({
  template: `
    <h1 mat-dialog-title>Create link</h1>
    <div mat-dialog-content>
      <p>What kind of link does it need to be?</p>
      <mat-form-field>
        <mat-select [(value)]="selectedRole">
          <mat-option value="User" selected="true">User</mat-option>
          <mat-option *ngFor="let role of roles" [value]="role">
            {{role}}
          </mat-option>
        </mat-select>
      </mat-form-field>
    </div>
    <div mat-dialog-content id="confirm-btn">
      <p>
        <button mat-button color="primary" (click)="goBack()">Go back</button>
      </p>
      <p>
        <button mat-raised-button color="primary" (click)="continue()">Continue</button>
      </p>
    </div>
  `,
  styles: [`
    #confirm-btn {
      display: flex;
    }

    #confirm-btn p {
      width: fit-content;
      margin-top: 20px;
    }

    #confirm-btn p:first-of-type {
      margin-right: auto;
    }
  `]
})

export class LinkCreateDialogComponent {

  roles = ['Vip', 'Admin'];
  selectedRole = 'User';

  constructor(public dialogRef: MatDialogRef<LinkCreateDialogComponent>) {}

  setNewValue(value) {
    this.selectedRole = value;
  }

  goBack(): void {
    this.dialogRef.close('Guest');
  }

  continue() {
    this.dialogRef.close(this.selectedRole);
  }
}
