import {Component} from '@angular/core';
import {MatDialogRef} from '@angular/material';

@Component({
  template: `
    <h1 mat-dialog-title>Are you sure?</h1>
    <div mat-dialog-content>
      <p>This link wil not be able to be used anymore.</p>
    </div>
    <div mat-dialog-content id="confirm-btn">
      <p>
        <button mat-button color="primary" (click)="goBack()">Go back</button>
      </p>
      <p>
        <button mat-raised-button color="primary" (click)="continue()">Continue</button>
      </p>
    </div>
  `,
  styles: [`
    #confirm-btn {
      display: flex;
    }
    #confirm-btn p{
      width: fit-content;
      margin-top: 20px;
    }
    #confirm-btn p:first-of-type{
      margin-right: auto;
    }
  `]
})

export class InviteToggleDialogComponent {

  constructor(public dialogRef: MatDialogRef<InviteToggleDialogComponent>) {}

  goBack(): void {
    this.dialogRef.close(false);
  }

  continue() {
    this.dialogRef.close(true);
  }
}
