import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AuthRoutingModule} from '../auth/auth-routing.module';
import {BrowserModule} from '@angular/platform-browser';
import {RouterModule} from '@angular/router';
import {MatModule} from '../core/mat.module';
import {InviteLinkComponent} from './invite-link/invite-link.component';
import {LinkService} from './service/link.service';
import {AdminLinksRouterModule} from './admin-links-routing.module';
import {AngularFirestore} from '@angular/fire/firestore';
import {InviteToggleDialogComponent} from './dialog/invite-toggle-dialog.component';
import {LinkDialogService} from './service/link-dialog.service';
import {LinkCreateDialogComponent} from './dialog/link-create-dialog.component';
import {LinkDeleteDialogComponent} from './dialog/link-delete-dialog.component';
import {CodeGeneratorService} from './service/code-generator.service';

@NgModule({
  declarations: [
    InviteLinkComponent,
    InviteToggleDialogComponent,
    LinkCreateDialogComponent,
    LinkDeleteDialogComponent
  ],
  imports: [
    BrowserAnimationsModule,
    AdminLinksRouterModule,
    ReactiveFormsModule,
    AuthRoutingModule,
    BrowserModule,
    RouterModule,
    CommonModule,
    FormsModule,
    MatModule,
  ],
  exports: [
    InviteLinkComponent,
    AdminLinksRouterModule,
    InviteToggleDialogComponent,
    LinkCreateDialogComponent,
    LinkDeleteDialogComponent
  ],
  providers: [
    LinkService,
    LinkDialogService,
    AngularFirestore,
    CodeGeneratorService
  ],
  entryComponents: [
    InviteToggleDialogComponent,
    LinkCreateDialogComponent,
    LinkDeleteDialogComponent
  ]
})
export class AdminLinksModule {

}
