import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {InviteLinkComponent} from './invite-link/invite-link.component';
import {AuthGuard} from '../auth/guard/auth.guard';

const linksRoutes: Routes = [];

@NgModule({
  imports: [RouterModule.forChild(linksRoutes)],
  exports: [RouterModule]
})
export class AdminLinksRouterModule {
}

