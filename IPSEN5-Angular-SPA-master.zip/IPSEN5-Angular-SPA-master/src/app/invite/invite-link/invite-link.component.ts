import {Component, OnInit} from '@angular/core';
import {InviteLink} from '../model/invite-link';
import {LinkDialogService} from '../service/link-dialog.service';
import {LinkService} from '../service/link.service';

@Component({
  selector: 'app-admin-link',
  templateUrl: './invite-link.component.html',
  styleUrls: ['./invite-link.component.css']
})
export class InviteLinkComponent implements OnInit {

  inviteLinks: InviteLink[] = [];
  displayedColumns = ['used', 'link', 'role', 'delete'];
  linkRuleState: boolean;

  constructor(private linkService: LinkService, private linkDialogService: LinkDialogService) {
    linkService.getRefCodes().subscribe((inviteLinks: InviteLink[]) => {
      this.inviteLinks = inviteLinks;
    });
    linkService.getUpInviteRule().subscribe((ruleState: boolean) => {
      this.linkRuleState = ruleState;
    });
  }

  ngOnInit() {
  }

  showCreateDialog() {
    this.linkDialogService.displayCreateLink();
  }

  showDeleteWarning(inviteLink) {
    this.linkDialogService.displayDeleteWarning(inviteLink.docRef);
  }

  toggleUsageRefLinks() {
    this.linkDialogService.displayToggleWarning();
  }

  copyToClipBoard(input, toolTip) {
    input.select();
    document.execCommand('copy');
    input.blur();

    toolTip.message = 'Copied to clipboard';
    toolTip.show();

    this.wait2Seconds().then(() => {
      toolTip.hide();
      toolTip.message = 'Click to copy to clipboard';
    });
  }

  wait2Seconds() {
    return new Promise(resolve => {
      window.setTimeout(function () {
        resolve(true);
      }, 2000);
    });
  }
}

