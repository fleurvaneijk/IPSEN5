import {Injectable} from '@angular/core';
import {root} from 'rxjs/internal-compatibility';

@Injectable({
  providedIn: 'root'
})
export class CodeGeneratorService {

  constructor() {}

  generateNewCode(): Array<string> {
    const sizePartOne = this.randomInt(18, 23);
    const sizePartTwo = this.randomInt(18, 23);
    const sizePartThree = 64 - (sizePartOne + sizePartTwo);
    return [this.getRandomString(sizePartOne), this.getRandomString(sizePartTwo), this.getRandomString(sizePartThree)];
  }

  getRandomString(size: number) {
    let randomString = '';
    for (let i = 0; i < size; i++) {
      const charCode = this.randomInt(0, 61);
      let addition = 48;
      addition += charCode > 9 ? 7 : 0;
      addition += charCode > 35 ? 6 : 0;
      randomString += String.fromCharCode(charCode + addition);
    }
    return randomString;
  }

  randomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}
