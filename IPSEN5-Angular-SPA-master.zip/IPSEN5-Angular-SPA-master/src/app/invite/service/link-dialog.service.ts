import {Injectable} from '@angular/core';
import {MatDialog} from '@angular/material';
import {LinkDeleteDialogComponent} from '../dialog/link-delete-dialog.component';
import {LinkService} from './link.service';
import {InviteToggleDialogComponent} from '../dialog/invite-toggle-dialog.component';
import {LinkCreateDialogComponent} from '../dialog/link-create-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class LinkDialogService {

  constructor(public dialog: MatDialog, private linkService: LinkService) {
  }

  displayCreateLink() {
    const dialogRef = this.dialog.open(LinkCreateDialogComponent, {
      maxWidth: '80%',
      minWidth: '350px',
      width: '25%',
      closeOnNavigation: false,
      disableClose: true
    });
    dialogRef.afterClosed().subscribe(result => {
      if (typeof result === 'string') {
        this.linkService.createNewRefCode(result);
      }
    });
  }

  displayDeleteWarning(linkDocRef) {
    const dialogRef = this.dialog.open(LinkDeleteDialogComponent, {
      maxWidth: '80%',
      minWidth: '350px',
      width: '25%',
      closeOnNavigation: false,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result: boolean) => {
      if (result) {
        this.linkService.deleteLink(linkDocRef);
      }
    });
  }

  displayToggleWarning() {
    const dialogRef = this.dialog.open(InviteToggleDialogComponent, {
      maxWidth: '80%',
      minWidth: '350px',
      width: '25%',
      closeOnNavigation: false,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result: boolean) => {
      if (result) {
        this.linkService.toggleLinks();
      }
      this.linkService.updateToggle();
    });
  }


}
