import {Injectable} from '@angular/core';
import {AngularFirestore, AngularFirestoreCollection} from '@angular/fire/firestore';
import {root} from 'rxjs/internal-compatibility';
import {InviteLink} from '../model/invite-link';
import {BehaviorSubject} from 'rxjs';
import {CodeGeneratorService} from './code-generator.service';

@Injectable({
  providedIn: 'root'
})
export class LinkService {

  inviteReference: AngularFirestoreCollection = this.firestore.collection('/invite/');
  inviteRulesReference: AngularFirestoreCollection = this.firestore.collection('/registration/');

  inviteLinks: BehaviorSubject<InviteLink[]> = new BehaviorSubject([]);
  inviteRule: BehaviorSubject<boolean> = new BehaviorSubject(true);

  constructor(private firestore: AngularFirestore, private codeGeneratorService: CodeGeneratorService) {
    this.setUpRefCodes();
    this.setUpInviteRule();
  }

  getRefCodes() {
    return this.inviteLinks;
  }

  getUpInviteRule() {
    return this.inviteRule;
  }

  setUpRefCodes() {
    this.inviteReference.snapshotChanges().subscribe(records => {
      const inviteLinks = [];
      records.forEach(record => {
        const doc = record.payload.doc;
        inviteLinks.push(new InviteLink(doc.id, doc.data()));
      });
      this.inviteLinks.next(inviteLinks);
    });
  }

  setUpInviteRule() {
    this.inviteRulesReference.doc('registrationRule').valueChanges().subscribe((data: any) => {
      this.inviteRule.next(data.inviteOnly);
    });
  }

  createNewRefCode(role = 'User') {
    const code = this.codeGeneratorService.generateNewCode();
    this.inviteReference.add({
      userUID: null,
      role: role,
      codePart1: code[0],
      codePart2: code[1],
      codePart3: code[2],
      used: false
    }).then(data => {
    }).catch(data => {
    });
  }

  deleteLink(inviteDocRef) {
    this.inviteReference.doc(inviteDocRef).delete().then(() => {
    }).catch(() => {
    });
  }

  toggleLinks() {
    const linkRuleState = this.inviteRule.getValue();
    this.inviteRulesReference.doc('registrationRule').update({
      inviteOnly: !linkRuleState
    });
  }

  updateToggle() {
    this.inviteRule.next(this.inviteRule.getValue());
  }
}
