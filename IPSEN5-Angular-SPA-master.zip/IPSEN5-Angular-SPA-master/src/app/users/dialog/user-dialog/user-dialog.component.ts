import {Component, EventEmitter, Inject, Input, OnInit, Output} from '@angular/core';
import {User} from '../../../core/shared/models/user.model';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material';
import {DialogData} from '../../users-list/user-list.component';
import {UserService} from '../../../core/shared/services/user.service';
import {UserLicensesDialogComponent} from '../user-licenses-dialog/user-licenses-dialog.component';

@Component({
  selector: 'app-user-modal',
  templateUrl: './user-dialog.component.html'
})
export class UserDialogComponent implements OnInit {
  @Input() user: User;
  private readonly admin;

  private save: EventEmitter<User>;
  private new: EventEmitter<User>;
  private delete: EventEmitter<User>;
  private upgrade: EventEmitter<User>;
  private resetPassword: EventEmitter<User>;

  constructor(private userService: UserService,
              public dialogLicenses: MatDialog,
    public dialogRef: MatDialogRef<UserDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {
    // Injected by openDialog() in users-list.component.ts
      this.setUser(this.data.user);
      this.save = (this.data.save);
      this.new = (this.data.new);
      this.delete = (this.data.delete);
      this.upgrade = (this.data.upgrade);
      this.admin = (this.data.admin);
      this.resetPassword = (this.data.resetPassword);
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  ngOnInit() {
    // this.setUser(this.data.user);
  }

  private getUser() {
    return this.user;
  }

  private setUser(user: User) {
    this.user = user;
  }

  onDeleteButtonClickUser($event: MouseEvent) {
    this.delete.emit(this.getUser());
  }

  onUpdateButtonClickUser(event) {
    this.save.emit(this.getUser());
   }

  onNewButtonClickUser(admin) {
    const user = this.getUser();
    user.role = this.admin;
    this.new.emit(user);
  }

  onResetEmailButtonUser(user: User) {
    this.resetPassword.emit(user);
  }

  onMakeVipButtonUser(user: User) {
    this.upgrade.emit(user);
  }

  onViewLicensesButtonUser(element: User) {
    const dialogRefLicenses = this.dialogLicenses.open(UserLicensesDialogComponent, {
      width: '350px',
      data: {
        licenses: element.licenses,
      }
    });

    dialogRefLicenses.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      // this.animal = result;
    });
  }
}
