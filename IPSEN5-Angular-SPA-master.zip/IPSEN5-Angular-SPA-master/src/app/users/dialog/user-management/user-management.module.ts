import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {UserManagementComponent} from './user-management.component';
import {MatModule} from '../../../core/mat.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import {MatGridListModule, MatTabsModule} from '@angular/material';
import {FileDropModule} from 'ngx-file-drop';

@NgModule({
  declarations: [
    UserManagementComponent
  ],
  imports: [
    CommonModule,
    MatModule,
    ReactiveFormsModule,
    MatModule,
    BrowserModule,
    MatGridListModule,
    FileDropModule,
    FormsModule,
    ReactiveFormsModule,
    MatTabsModule
  ],
  exports: [
    UserManagementComponent
  ]
})
export class UserManagementModule { }
