import {Component, OnDestroy, OnInit} from '@angular/core';
import {AuthService} from '../../../core/shared/services/auth.service';
import {ActivatedRoute, Router} from '@angular/router';
import {takeUntil} from 'rxjs/operators';
import {Subject} from 'rxjs';

export enum UserManagementActions {
  'resetPassword'
}

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styles: [`
    #confirm-btn {
      display: flex;
    }

    #confirm-btn p {
      width: fit-content;
      margin-top: 20px;
    }

    #confirm-btn p:first-of-type {
      margin-right: auto;
    }
  `]
})
export class UserManagementComponent implements OnInit, OnDestroy {

  ngUnsubscribe: Subject<any> = new Subject<any>();
  mode: string;
  actionCode: string;

  oldPassword: string;
  newPassword: string;
  confirmPassword: string;

  actionCodeChecked: boolean;

  constructor(private router: Router, private activatedRoute: ActivatedRoute, private authService: AuthService) { }

  ngOnInit() {
    this.activatedRoute.queryParams
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe(params => {
        if (!params) { this.router.navigate(['/login']); }

        this.mode = params['mode'];
        this.actionCode = params['oobCode'];
        if (this.mode === 'resetPassword') {
            // Verify the password reset code is valid.
            this.authService
              .getAuth()
              .verifyPasswordResetCode(this.actionCode)
              .then(email => {
                this.actionCodeChecked = true;
              }).catch(e => {
              // Invalid or expired action code. Ask user to try to
              // reset the password again.
              console.log(e);
              this.router.navigate(['login']);
            });
        } else {
            alert('query parameters are missing' + this.mode);
            this.router.navigate(['login']);
        }
      });
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  /**
   * Attempt to confirm the password reset with firebase and
   * navigate user back to home.
   */
  handleResetPassword() {
    if (this.newPassword !== this.confirmPassword) {
      alert('New Password and Confirm Password do not match');
      return;
    }
    this.authService.getAuth().confirmPasswordReset(
      this.actionCode,
      this.newPassword
    )
      .then(resp => {
        alert('New password has been saved');
        this.router.navigate(['/auth/login']);
      }).catch(e => {
        console.log(e);
      });
  }
}
