import {Component, EventEmitter, Inject, Input, OnInit, Output} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {User} from '../../../core/shared/models/user.model';

@Component({
  selector: 'app-user-licenses-modal',
  templateUrl: './user-licenses-dialog.component.html'
})
export class UserLicensesDialogComponent implements OnInit {
  @Input() user: User;
  private readonly admin;
  licenses: Array<string>;

  constructor(public dialogRef: MatDialogRef<UserLicensesDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    // Injected by openDialog() in users-list.component.ts
      this.setUser(this.data.user);
      this.licenses = this.data.licenses;
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  ngOnInit() {
  }

  private getUser() {
    return this.user;
  }

  private setUser(user: User) {
    this.user = user;
  }
}
