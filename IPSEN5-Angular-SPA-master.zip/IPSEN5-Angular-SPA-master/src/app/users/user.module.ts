import {NgModule} from '@angular/core';
import {MatModule} from '../core/mat.module';
import {BrowserModule} from '@angular/platform-browser';
import {MatGridListModule, MatInput, MatInputModule, MatTabsModule} from '@angular/material';
import {FileDropModule} from 'ngx-file-drop';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {UserListComponent} from './users-list/user-list.component';
import {UserDialogComponent} from './dialog/user-dialog/user-dialog.component';
import {UsersRoutingModule} from './users-routing.module';
import {UsersComponent} from './users/users.component';
import {UserLicensesDialogComponent} from './dialog/user-licenses-dialog/user-licenses-dialog.component';

@NgModule({
  declarations: [
    UsersComponent,
    UserListComponent,
    UserDialogComponent,
    UserLicensesDialogComponent
  ],
  imports: [
    MatModule,
    MatInputModule,
    BrowserModule,
    MatGridListModule,
    FileDropModule,
    FormsModule,
    ReactiveFormsModule,
    MatTabsModule
  ],
  entryComponents: [
    UserDialogComponent,
    UserLicensesDialogComponent
  ],
  exports: [
    UsersComponent,
    UserListComponent,
    UsersRoutingModule,
    UserLicensesDialogComponent
  ]
})
export class UserModule {
}
