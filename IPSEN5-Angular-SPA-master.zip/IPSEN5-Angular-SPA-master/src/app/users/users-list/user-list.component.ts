import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {User} from '../../core/shared/models/user.model';
import {UserDialogComponent} from '../dialog/user-dialog/user-dialog.component';
import {MatDialog, MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {UserService} from '../../core/shared/services/user.service';
import {InviteLinkComponent} from '../../invite/invite-link/invite-link.component';
export interface DialogData {
  save: EventEmitter<User>;
  new:  EventEmitter<User>;
  delete:  EventEmitter<User>;
  upgrade:  EventEmitter<User>;
  resetPassword:  EventEmitter<User>;
  user: User;
  admin: number;
}

const ELEMENT_DATA: User[] = [
  {docId: '214123', uid: '1', role: 'User', fullName: 'kees', email: 'testemail1', licenses: [ 'Hi'], orderHistory: []}
];
@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  @Input() users: User[];
  @Input() openIndexUser;
  @Input() admin;

  // Injected by users.component.html
  @Output() save: EventEmitter<User> = new EventEmitter();
  @Output() new:  EventEmitter<User> = new EventEmitter();
  @Output() delete:  EventEmitter<User> = new EventEmitter();
  @Output() upgrade:  EventEmitter<User> = new EventEmitter();
  @Output() resetPassword:  EventEmitter<User> = new EventEmitter();

  displayedColumns: string[] = ['select', 'fullName', 'email', 'licenses'];
  dataSource = new MatTableDataSource<User>(ELEMENT_DATA);
  selection = new SelectionModel<User>(true, []);

  constructor(private userService: UserService, public dialog: MatDialog) {}

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: User): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    // return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  }

  ngOnInit(): void {
    this.userService.getAll().subscribe(data => {
      this.users = data.map(e => {
        return {
          docId: e.payload.doc.id,
          ...e.payload.doc.data()
        } as unknown as User;
      }).filter(word => word.role === this.admin);
    });
  }

  onAddButtonClickUser(admin) {
    switch (admin) {
      // case 'Vip': {
      //   // open vip registreren
      //   break;
      // }
      // case 'Admin': {
      //   // open vip registreren
      //   break;
      // }
      default: {
        const dialogRef = this.dialog.open(InviteLinkComponent, {
          width: '450px',
        });

        dialogRef.afterClosed().subscribe(result => {
          console.log('The dialog was closed');
        });

        break;
      }
    }
  }

  openDialog(element): void {
    this.openIndexUser = element.uid;
    const dialogRef = this.dialog.open(UserDialogComponent, {
      width: '250px',
      data: {
        user: element,
        save: this.save,
        new: this.new,
        delete: this.delete,
        upgrade: this.upgrade,
        admin: this.admin,
        resetPassword: this.resetPassword
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      // this.animal = result;
    });
  }
}
