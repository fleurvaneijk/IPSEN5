import {Component, OnInit} from '@angular/core';
import {UserService} from '../../core/shared/services/user.service';
import {User} from '../../core/shared/models/user.model';
import {AuthService} from '../../core/shared/services/auth.service';

@Component({
  selector: 'app-user',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  private users: User[];
  openIndexUser: number;
  private usersAdmin: User[];
  private usersNormal: User[];

  constructor(private auth: AuthService, private userService: UserService) {
  }

  ngOnInit() {
    this.users = this.userService.getDummyUsers();
    this.usersAdmin = this.users;
    this.usersNormal = this.users;
  }

  onSaveEvent(user: User) {
    // TODO attribuut ID automatisch zetten bij het creeren van een user
    this.userService.update(user, user.docId).then(next => {
      console.log(next + ' updated!');
    }).catch((err) => {
      console.log('iets ging met bij het bewerken van een user!' + err);
    });
  }

  onNewEvent(user: User) {
    this.userService.add(user).then(next => {
      // user.uid = next.;
      // this.userService.update(user, next.id).then(nextnext => {
      //   // TODO email register invite-link
      //   console.log('user aangemaakt!');
      // }).catch((err) => {
      //   console.log('iets ging met bij het toevoegen van een user uid!' + err);
      // });
    }).catch((err) => {
      console.log('iets ging met bij het toevoegen van een user!' + err);
    });
  }

  onRemoveEvent(user: User) {
    this.userService.delete(user.docId).then(next => {
      console.log(next + ' deleted');
    }).catch((err) => {
      console.log('iets ging met bij het verwijderen van een user!');
    });
  }

  onUpgradeEvent(user: User) {
    user = this.userService.setRoleVip(user);
    this.userService.update(user, user.docId).then(next => {
      console.log(next + ' upgraded!');
    }).catch((err) => {
      console.log('iets ging met bij het bewerken van een user!' + err);
    });
  }

  onResetPasswordEvent(user: User) {
    if (!user.email) {
      alert('Type in your email first');
    }
    this.auth.resetPasswordInit(user.email)
      .then(
        () => alert('A password reset invite-link has been sent to your email address'),
        (rejectionReason) => alert(rejectionReason))
      .catch(e => alert('An error occurred while attempting to reset your password'));
  }
}
