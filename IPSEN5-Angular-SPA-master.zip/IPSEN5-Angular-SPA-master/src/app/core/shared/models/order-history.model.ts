export interface OrderHistoryRecord {
  date: number;
  songId: string;
}
